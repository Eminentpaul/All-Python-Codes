line = '34 23 1 24 75 33 54 8 60'
a = line.strip().split()
mx = -1
c = 0
for x in range(len(a)):
    for i in a:
        c = int(i) + int(a[x])
        if c > mx and c < 60:
            mx = c
        else: print(mx)
print(mx)
