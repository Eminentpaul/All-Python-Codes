import time

from flask import Flask, request, render_template, redirect, session
import sqlite3
from datetime import datetime

app = Flask(__name__)
app.secret_key = "super secret key"


@app.route('/<string:unknown>')
def unknonw(unknown):
    return '<h1>404</h1>'


userss = ''
passs = ''


@app.route('/', methods=['GET', 'POST'])
def index():
    global error, userss

    if request.method == "POST":
        username = request.form.get('username')
        passwords = request.form.get('pass')
        con = sqlite3.connect('database.db')
        cursor = con.cursor()
        cursor.execute("select * from user")
        rows = cursor.fetchall()
        p = []
        v = []
        for row in rows:
            p.append(row[2])
            v.append(row[1])
            print(row)
        if username in v and passwords in p:
            session['user'] = username
            update = "Online"
            if cursor.execute("update user set login_status=='" + update + "' where username=='" + username + "'"):
                con.commit()
            return redirect("/home")
        else:
            return "Invalid Username or Password"

    else:
        return render_template('signin.html')


@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == "POST":
        username = request.form.get('username')
        password = request.form.get('user_pass')
        cpass = request.form.get('user_cpass')
        user_email = request.form.get('user_email')
        user_state = request.form.get('user_state')
        gender = request.form.get('sex')
        login_status = 'Offline'
        last_login = datetime.today().strftime('%H:%M:%S %d-%m-%Y')
        if password != cpass:
            error = 'The Password is not the same!'
            return error
        else:
            con = sqlite3.connect('database.db')
            cursor = con.cursor()
            cursor.execute("SELECT * FROM user")
            rows = cursor.fetchall()
            # return username
            for row in rows:
                # return row[1] + " Names"
                if row[1] == username:
                    return "username has been used"
                else:
                    query = "INSERT INTO user(username, password, email, state, gender, login_status, last_login) VALUES('" + username + "', '" + password + "', '" + user_email + "', '" + user_state + "', '" + gender + "', '" + login_status + "', '" + last_login + "')"
                    if cursor.execute(query):
                        con.commit()
                        return redirect("/")
    else:
        return render_template('signup.html')


@app.route('/home')
def home():
    if 'user' in session:
        user = session['user']
        con = sqlite3.connect('database.db')
        cursor = con.cursor()
        cursor.execute("select * from posts")
        row = cursor.fetchall()
        return render_template("index.html", user=user, rows=row)
        # return user
    else:
        return redirect('/')


@app.route('/dashboard')
def dashboard():
    if 'user' in session:
        user = session['user']

        con = sqlite3.connect('database.db')
        cursor = con.cursor()
        cursor.execute("select * from user where username=='" + user + "'")
        rows = cursor.fetchall()
        cursor.execute("select * from posts where user=='" + user + "'")
        posts = cursor.fetchall()

        return render_template('dashboard.html', rows=rows, posts=posts)
    else:
        return redirect('/')


@app.route('/chat/<friend>', methods=['GET', 'POST'])
def chat(friend):
    if 'user' in session:
        user = session['user']
        con = sqlite3.connect('database.db')
        cursor = con.cursor()
        # print(friend)
        sender = user
        receiver = friend
        date = datetime.today().strftime('%H:%M:%S %d-%m-%Y')
        if request.method == "POST":
            msg = request.form.get('message')
            cursor.execute(
                'insert into chats(sender, receiver, msg_content, msg_date) values("' + sender + '", "' + receiver + '", "' + msg + '", "' + str(
                    date) + '")')
            con.commit()
        cursor.execute("select * from user")
        rows = cursor.fetchall()

        while cursor.execute("SELECT * FROM chats WHERE(sender=='"+sender+"' AND receiver=='"+receiver+"') OR (receiver=='"+sender+"' AND sender=='"+receiver+"') ORDER by 1 ASC"):
            messages = cursor.fetchall()
            snd = []
            rec = []
            for row in messages:
                rec.append(row[2])
                snd.append(row[1])
            print(snd, rec)


            return render_template('chat.html',sends=snd, receives=rec, msg=messages, user=user, rows=rows, name=friend)

    else:
        return redirect('/')


@app.route('/new_post', methods=['GET', 'POST'])
def new_post():
    if 'user' in session:
        user = session['user']
        if request.method == "POST":
            title = request.form.get('title')
            content = request.form.get('content')
            date = str(datetime.today().strftime('%H:%M:%S %d-%m-%Y'))
            con = sqlite3.connect('database.db')
            cursor = con.cursor()
            cursor.execute(
                'insert into posts(user, title, content, date) values("' + user + '", "' + title + '", "' + content + '", "' + date + '")')
            con.commit()
            con.close()
            return redirect('/dashboard')
        else:
            return render_template('new_post.html')
    else:
        return redirect('/')


@app.route('/logout')
def logout():
    if 'user' in session:
        user = session['user']
        con = sqlite3.connect('database.db')
        cursor = con.cursor()
        update = 'Offline'
        if cursor.execute("update user set login_status=='"+update+"' where username=='" + user + "'"):
            con.commit()
            session['user'] = None
            time.sleep(1)
        return redirect('/')


@app.route('/delete/<string:id>')
def delete(id):
    if 'user' in session:
        user = session['user']
        con = sqlite3.connect('database.db')
        cursor = con.cursor()
        cursor.execute("delete from posts where id=='" + id + "' and user=='" + user + "'")
        con.commit()
        return redirect('/dashboard')


if __name__ == "__main__":
    app.run(debug=True)
