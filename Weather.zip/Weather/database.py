import sqlite3

con = sqlite3.connect('database.db')
cursor = con.cursor()
from datetime import datetime

table = """CREATE TABLE IF NOT EXISTS user(
    id integer primary key autoincrement,
    username varchar(25) not null,
    password text not null,
    email text not null,
    state text not null,
    gender text not null,
    login_status text not null,
    last_login text not null
)"""

tables = """CREATE TABLE IF NOT EXISTS chats(
    id integer primary key autoincrement,
    sender text not null,
    receiver text not null,
    msg_content text not null,
    msg_date text not null
)"""

post = """CREATE TABLE IF NOT EXISTS posts(
    id integer primary key autoincrement,
    user text not null,
    title text not null,
    content text not null,
    date text not null
)"""
a = datetime.today().strftime('%Y-%m-%d %H:%M:%S')
b =[1,2]
c =[3,4]
for i,x in b,c:
    print(i, x)
print(a)
if cursor.execute(tables):
    print(post)
