guess_number = 11

guess_count = 3
guess_limit = 0

while guess_limit < guess_count:
    Guess = int(input("Guess the Number: "))
    guess_limit += 1
    if Guess == guess_number:
        print("You won!")
        break
else:
    print("You loose!")