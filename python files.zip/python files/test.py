import _sqlite3 as mysql
from tkinter import *
from tkinter import messagebox as message

root = Tk()
root.geometry("1000x600")


# con = mysql.connect('eminent.db')
# cursor = con.cursor()
# cursor.execute("""CREATE TABLE class(
#                 first_name text,
#                 last_name text,
#                 address text,
#                 gender text,
#                 phone_number integer
#                 )""")

genderm = StringVar()


def std_list():
    con = mysql.connect('eminent.db')
    cursor = con.cursor()

    cursor.execute("SELECT * FROM class")

    rows = cursor.fetchall()
    list.delete(0, list.size())

    for row in rows:
        insertData = f"{row[1]}    {row[0]}    {row[2]}    {row[3]}    {row[4]}"
        list.insert(list.size()+1, insertData)

    # cursor.execute('commit')


def submit():
    f_name = e_first_name.get().upper()
    l_name = e_last_name.get().upper()
    genders = genderm.get().upper()
    location = e_address.get().upper()
    phone_num = e_phone.get()

    if (f_name=="" or l_name=="" or location=="" or phone_num==""):
        message.showinfo("Message", "All Fields are required")
    else:
        con = mysql.connect('eminent.db')
        cursor = con.cursor()
        cursor.execute("SELECT * FROM class")
        rows = cursor.fetchall()

        for row in rows:
            if(row[0]==f_name):
                message.showinfo("Message", "The Name has been used")
                break
        else:
            if(cursor.execute("INSERT INTO class VALUES('"+ f_name +"', '"+ l_name +"', '"+ location +"', '"+ genders +"', '"+ phone_num +"')")):
                cursor.execute('commit')
                message.showinfo("Message", "Submitted Successfuly")

        e_first_name.delete(0, END)
        e_last_name.delete(0, END)
        e_address.delete(0, END)
        e_phone.delete(0, END)
        std_list()
        # genderm.delete(0, END)

        cursor.execute('commit')
        # con.close()


def get():
    f_name = e_first_name.get().upper()
    # l_name = e_last_name.get()
    # genders = genderm.get()
    # location = e_address.get()
    # phone_num = e_phone.get()

    if (f_name == ""):
        message.showinfo("Message", "The First Name is needed")
    else:
        # top = Toplevel()
        con = mysql.connect('eminent.db')
        cursor = con.cursor()
        cursor.execute("SELECT * FROM class WHERE first_name='"+ f_name +"'")

        rows = cursor.fetchall()

        for row in rows:
            if(row[0]==f_name):
                top = Toplevel()
                top.geometry("1000x600")
                label = Label(top, text=rows).pack()

            else:
                message.showinfo("Message", "Not found in the List of Students")
            break


            # message.showinfo("Message", "Submitted Successfuly")

            # e_first_name.delete(0, END)
            # e_last_name.delete(0, END)
            # e_address.delete(0, END)
            # e_phone.delete(0, END)
            # # genderm.delete(0, END)

        # cursor.execute('commit')
        # con.close()


def delete():
    con = mysql.connect('eminent.db')
    cursor = con.cursor()
    f_name = e_first_name.get().upper()

    if (f_name == ""):
        message.showinfo("Message", "The First Name is needed")
    else:
        clear = cursor.execute("DELETE FROM class WHERE first_name='" + f_name + "'")
        cursor.execute('commit')

        if clear:
            message.showinfo("Message", "Deleted Successfully")
        else:
            message.showinfo("Message", "Didn't Found such Name")


    std_list()

    con.close()

# def std_list():
#     con = mysql.connect('eminent.db')
#     cursor = con.cursor()
#
#     cursor.execute("SELECT * FROM class")
#     rows = cursor.fetchall()
#     list.delete(0, list.size())
#
#     for row in rows:
#         insertData = f"{row[1]}    {row[0]}    {row[2]}    {row[3]}    {row[4]}"
#         list.insert(list.size()+1, insertData)





first_name = Label(root, text="First Name:", pady=14, font=("Tahoma", 15, "bold"))
first_name.place(x=20, y=30)
e_first_name = Entry(root, width=30, font=("Tahoma", 10, "bold"))
e_first_name.place(x=140, y=50)

last_name = Label(root, text="Last Name:", pady=14, font=("Tahoma", 15, "bold"))
last_name.place(x=380, y=30)
e_last_name = Entry(root, width=30, font=("Tahoma", 10, "bold"))
e_last_name.place(x=500, y=50)

address = Label(root, text="Address:", pady=14, font=("Tahoma", 15, "bold"))
address.place(x=20, y=90)
e_address = Entry(root, width=30, font=("Tahoma", 10, "bold"))
e_address.place(x=140, y=110)

gender = Label(root, text="Gender:", pady=14, font=("Tahoma", 15, "bold"))
gender.place(x=380, y=90)

radio_male = Radiobutton(root, text="Male", variable=genderm, value="Male", font=("Tahoma", 15, "bold"))
radio_male.place(x=480, y=100)
radio_female = Radiobutton(root, text="Female", variable=genderm, value="Female", font=("Tahoma", 15, "bold"))
radio_female.place(x=570, y=100)

phone = Label(root, text="Phone No:", pady=14, font=("Tahoma", 15, "bold"))
phone.place(x=20, y=150)
e_phone = Entry(root, width=30, font=("Tahoma", 10, "bold"))
e_phone.place(x=140, y=170)

submit_btn = Button(root, text="Submit", font=("tahoma", 15, "bold"),
                    bg="green", fg="white", command=submit).place(x=400, y=160)

get_btn = Button(root, text="Get", font=("tahoma", 15, "bold"),
                    bg="black", fg="white", command=get).place(x=490, y=160)

delete_btn = Button(root, text="Delete", font=("tahoma", 15, "bold"),
                    bg="red", fg="white", command=delete).place(x=550, y=160)

exit_btn = Button(root, text="Close", font=("tahoma", 15, "bold"),
                    bg="yellow", fg="black", command=root.quit).place(x=650, y=160)


list = Listbox(root, width=90, height=20)
list.place(x=20, y=220)
std_list()


root.mainloop()
