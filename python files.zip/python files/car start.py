
pip install https://github.com/pyinstaller/pyinstaller/archive/develop.tar.gz



command = ""
car_started = False
while True:
     command = input('> ').lower()
     if command == 'start':
         if car_started:
             print('Car has been started')
         else:
             car_started = True
             print('Car Started... Ready to Go!')
     elif command == 'stop':
         if not car_started:
             print('Car has already stopped')
         else: 
            car_started = False
            print('Car Stopped')
     elif command == 'help':
         print("""
Start - to start the car
Stop - sto stop the car
Quit - to quit
         """)
     elif command == 'quit':
         break
     else:
        print("Sorry, I don't understand this...")







guess_number = 45
guess_count = 0
guess_limit = 3

while guess_count < guess_limit:
    Guess = int(input("Guess the Number: "))
    guess_count += 1
    if Guess != guess_number:
        print("Incorrect Try again")
    elif Guess == guess_number:
        print("You won!")
        break
else:
    print('Sorry, You Failed')
	
	
	
	
for x in range(4):
    for y in range(3):
        print(f"({x},{y})")







items = [5, 2, 5, 2, 2]

	for item in items:
	   print("x" * item)




items = [5, 2, 5, 2, 2]

for item in items:
    output = ""
    for x in range(item):
        output += "x"
    print(output)




number = [13, 13, 2, 2, 2, 2, 2, 2, 13, 13]
for item in number:
    output = ''
    for count in range(item):
        output += "x"
    print(output)
	
	
	
	
	DICTIONARY
	
phone = input('Phone ')
number = {
    "1": "One",
    "2": "Two",
    "3": "Three",
    "4": "Four"
}
output = ""
for character in phone:
    output += number.get(character, '!') + " "
print(output)
	
	
	
	from utils import find_max

numbers = [3, 55, 32, 5, 234]
max = find_max(numbers)
print(max)







import random

class Dice:
    def roll(self):
        first = random.randint(1, 6)
        second = random.randint(1, 6)
        return first, second

Dice1 = Dice()
done = Dice1.roll()

print(done)




// Get the maximum number in the list

number = [10, 20, 50, 30]

max_number = number[0]
for numbers in number:
    if numbers > max_number:
        max_number = numbers
print(max_number)




Removing duplicates in a list


numbers = [3, 34, 3, 5, 5, 4]
uniques = []
for number in numbers:
    if number not in uniques:
        uniques.append(number)
print(uniques)




for emoji DICTIONARY

message = input(">")
words = message.split(' ')

emojis = {
    ":)": "☺",
    ":(": "😥"
}

output = ""
for word in words:
    output += emojis.get(word, word) + " "
print(output)


POSITION ARGUMENT BEFORE KEYWORD ARGUMENT

def greet_user(last_name, first_name):
    print(f"Hi {last_name} {first_name}")
    print("You are welcomed here")


first_name = input("> ")
last_name = input("> ")
print('Start')
greet_user(first_name=first_name, last_name=last_name)



square and exception method:

try:
    def square(number):
        return number * number


    numbers = int(input('>'))
    result = square(numbers)
    print(f"The answer is: {result}")
except ValueError:
    print("Invalid Value!")


CLASSES;

class Point:
    def __init__(self, x, y, z):
        self.x = x
        self.y = y
        self.z = z

    def move(self):
        print("Move")

    def draw(self):
        print('Draw')


result = Point(10, 20, 30)
print(result.y * result.z * result.x)





class Person:
    def __init__(self, name):
        self.name = name

    def talk(self):
        print(f"Hi I am {self.name}")


message = input("Name: ")
result = Person(message)
result.talk()
print(f"My Name is: {result.name}")



class Mammal:
    def walk(self):
        print('Walk')


class Dog(Mammal):
    def bark(self):
        print("Barking")


class Cat(Mammal):
    pass


Dogq = Dog()
Dogq.walk()
Dogq.bark()
cats = Cat()
cats.walk()




try:
    import converter

    message = int(input("> "))
    unit = input("Unit: ").lower()

    if unit == 'lbs':
        result = converter.lbs_to_kg(message)
        print(f"Your weight in Kilogram is: {result} kg")
    elif unit == 'kg':
        result = converter.kg_to_lbs(message)
        print(f"Your weight in Pounds is: {result} Pound")
    else:
        print("I don't understand this!")

except ValueError:
    print("Invalid")





import random

numbers1 = [1, 2, 3, 4, 5, 6]
numbers2 = [1, 3, 2, 4, 5, 6]
result1 = random.choice(numbers1)
result2 = random.choice(numbers2)
print(f"({result1}, {result2})")


 

import random

class Dice:
    def roll(self):
        first = random.randint(1, 6)
        second = random.randint(1, 6)
        return first, second



dice = Dice()
result = dice.roll()
print(result)




from pathlib import Path

path = Path()
result = path.glob("*")

for files in result:
    print(files)





GUI

from tkinter import *

root = Tk()

myOutput = Label(root, text="This is my first Graphic User Infterface")

myOutput.pack()


root.mainloop()





from tkinter import *

root = Tk()

myLabel1 = Label(root, text="My name is Paulinus").grid(row=0, column=0)
myLabel2 = Label(root, text="My first grid text").grid(row=1, column=0)



root.mainloop()







from tkinter import *

root = Tk()

def my_click():
    text = Label(root, text="Click me to work!!!!", fg="red")
    text.pack()

myButton = Button(root, text="Click Me!", command=my_click, fg="yellow", bg="green").pack()

root.mainloop()





from tkinter import *


root = Tk()

name = Label(root, text="Full Name      ")
name.pack()
entry = Entry(root, width=50, fg="orange", borderwidth=5)
entry.pack()
entry.insert(0, "Enter your Name")


def my_click():
    text = Label(root, text="Hello " + entry.get())
    text.pack()

myButton = Button(root, text="Submit", command=my_click, fg="yellow", bg="green")
myButton.pack()
root.mainloop()








   SIMPLE CALCULATOR

from tkinter import *
from PIL import ImageTk, Image
import math

root = Tk()
root.title('Paulinus Calculator')
root.iconbitmap('D:\python\practice\image\icon.ico')


clear1 = ImageTk.PhotoImage(Image.open('D:\python\practice\image\del.png'), size=23, width=50)
square_root = ImageTk.PhotoImage(Image.open('D:\python\practice\image\sqr.png'))
square = ImageTk.PhotoImage(Image.open('D:\python\practice\image\square.png'))
division = ImageTk.PhotoImage(Image.open('D:\python\practice\image\divi.png'))
percent2 = ImageTk.PhotoImage(Image.open('D:\python\practice\image\percentw.png'))

entry = Entry(root, justify='right', width=32, relief=SUNKEN, insertwidth=12, font=("Tahoma", 15, "bold"))


def buttons(number):
    current = entry.get()
    entry.delete(0, END)
    entry.insert(0, f"{current}{number}")


def clear():
    entry.delete(first=0, last=END)


# def point(number):
#     entry.get()
#
#     entry.insert(1, number)
#     entry.destroy


def percent():
    try:
        first_number = entry.get()
        entry.delete(first=0, last=END)

        global first_num
        global operation
        operation = 'square'
        first_num = int(first_number)

        result = entry.insert(0, first_num / 100)
        return result
    except:
        entry.insert(0, "Invalid")


def square_root1():
    first_number = entry.get()
    entry.delete(first=0, last=END)

    global first_num
    global operation
    operation = 'square'
    first_num = int(first_number)

    result = entry.insert(0, first_num ** 0.5)
    return result
    # output = math.sqrt(first_num)
    # return output


def square1():
    first_number = entry.get()
    entry.delete(first=0, last=END)

    global first_num
    global operation
    operation = 'square'
    first_num = int(first_number)

    result = entry.insert(0, first_num * first_num)
    return result


def plus():
    first_number = entry.get()
    global first_num
    global operation
    operation = 'plus'
    first_num = int(first_number)
    entry.delete(first=0, last=END)


def minus():
    first_number = entry.get()
    global first_num
    global operation
    operation = 'minus'
    first_num = int(first_number)
    entry.delete(first=0, last=END)


def times():
    first_number = entry.get()
    global first_num
    global operation
    operation = 'times'
    first_num = int(first_number)
    entry.delete(first=0, last=END)


def divide():
    first_number = entry.get()
    global first_num
    global operation
    operation = 'divide'
    first_num = int(first_number)
    entry.delete(first=0, last=END)


def equal():
    second_number = int(entry.get())
    entry.delete(first=0, last=END)

    global Operation

    if operation == 'plus':
        result = entry.insert(0, first_num + second_number)
        return result
    elif operation == 'minus':
        result = entry.insert(0, first_num - second_number)
        return result
    elif operation == 'times':
        result = entry.insert(0, first_num * second_number)
        return result
    elif operation == 'divide':
        result = entry.insert(0, first_num / second_number)
        return result




button1 = Button(root, image=clear1, padx=10, pady=10, width=70, height=30, command=clear)
button2 = Button(root, image=percent2, padx=10, pady=10, width=70, height=30, command=percent)
button3 = Button(root, image=square_root, padx=40, pady=10, width=70, height=30, command=square_root1)
button4 = Button(root, image=square, padx=40, pady=10, width=70, height=30, command=square1)

button5 = Button(root, text='7', padx=30, pady=6, font=('arial', 10, "bold"), command=lambda: buttons(7))
button6 = Button(root, text='8', padx=30, pady=6, font=('arial', 10, "bold"), command=lambda: buttons(8))
button7 = Button(root, text='9', padx=30, pady=6, font=('arial', 10, "bold"), command=lambda: buttons(9))
button8 = Button(root, image=division, padx=40, pady=10, width=70, height=30, command=divide)

button9 = Button(root, text='4', padx=30, pady=6, font=('arial', 10, "bold"), command=lambda: buttons(4))
button10 = Button(root, text='5', padx=30, pady=6, font=('arial', 10, "bold"), command=lambda: buttons(5))
button11 = Button(root, text='6', padx=30, pady=6, font=('arial', 10, "bold"), command=lambda: buttons(6))
button12 = Button(root, text='X', padx=30, pady=6, command=times)

button13 = Button(root, text='1', padx=30, pady=6, font=('arial', 10, "bold"), command=lambda: buttons(1))
button14 = Button(root, text='2', padx=30, pady=6, font=('arial', 10, "bold"), command=lambda: buttons(2))
button15 = Button(root, text='3', padx=30, pady=6, font=('arial', 10, "bold"), command=lambda: buttons(3))
button16 = Button(root, text='-', padx=30, pady=6, font=('arial', 10, "bold"), command=minus)

button17 = Button(root, text='0', padx=30, pady=6, font=('arial', 10, "bold"), command=lambda: buttons(0))
button18 = Button(root, text='.', padx=30, pady=6, font=('arial', 10, "bold"), command=lambda: buttons('.'))
button_equal = Button(root, text='ANS', padx=30, pady=6, font=('arial', 10, "bold"), command=equal)
button_plus = Button(root, text='+', padx=30, pady=6, font=('arial', 10, "bold"), command=plus)
button_exit = Button(root, text='Exit Program', padx=30, pady=6, anchor=E, font=('tahoma', 10, "bold"), command=root.quit)

entry.grid(row=0, column=0, columnspan=4, pady=10, padx=6)
button1.grid(row=1, column=0, padx=10, pady=10)
button2.grid(row=1, column=1, padx=10, pady=10)
button3.grid(row=1, column=2, padx=10, pady=10)
button4.grid(row=1, column=3, padx=10, pady=10)

button5.grid(row=2, column=0, padx=10, pady=10)
button6.grid(row=2, column=1, padx=10, pady=10)
button7.grid(row=2, column=2, padx=10, pady=10)
button8.grid(row=2, column=3, padx=10, pady=10)

button9.grid(row=3, column=0, padx=10, pady=10)
button10.grid(row=3, column=1, padx=10, pady=10)
button11.grid(row=3, column=2, padx=10, pady=10)
button12.grid(row=3, column=3, padx=10, pady=10)

button13.grid(row=4, column=0, padx=10, pady=10)
button14.grid(row=4, column=1, padx=10, pady=10)
button15.grid(row=4, column=2, padx=10, pady=10)
button16.grid(row=4, column=3, padx=10, pady=10)

button17.grid(row=5, column=0, padx=10, pady=10)
button18.grid(row=5, column=1, padx=10, pady=10)
button_equal.grid(row=5, column=2, padx=10, pady=10)
button_plus.grid(row=5, column=3, padx=10, pady=10)
button_exit.grid(row=6, column=0, columnspan=4, sticky=E, padx=10, pady=10)


root.mainloop()








IMAGE VIEWWER


from tkinter import *
from PIL import ImageTk, Image

root = Tk()
root.title("Image Viewer")
root.iconbitmap('D:\EXPORTS\icon.ico')

img1 = ImageTk.PhotoImage(Image.open('D:\EXPORTS\pix\me1.jpg'))
img2 = ImageTk.PhotoImage(Image.open('D:\EXPORTS\pix\me2.jpg'))
img3 = ImageTk.PhotoImage(Image.open('D:\EXPORTS\pix\me3.jpg'))
img4 = ImageTk.PhotoImage(Image.open('D:\EXPORTS\pix\me4.jpg'))
img5 = ImageTk.PhotoImage(Image.open('D:\EXPORTS\pix\me5.jpg'))
img6 = ImageTk.PhotoImage(Image.open('D:\EXPORTS\pix\me6.jpg'))

image_list = [img1, img2, img3, img4, img5, img6]

label = Label(image=img1)
label.grid(row=0, column=0, columnspan=3)


num_image = str(len(image_list))
status = Label(root, text=f"Image 1 of {num_image}", bd=1, relief=SUNKEN, anchor=E, padx=6)
status.grid(row=2, column=0, columnspan=3, sticky=W+E)


def forward(image_number):
    global label
    global button_forward
    global button_back

    label.grid_forget()
    label = Label(image=image_list[image_number-1])
    button_forward = Button(root, text='>>', command=lambda: forward(image_number+1))
    button_back = Button(root, text='<<', command=lambda: back(image_number-1))

    if image_number == 6:
        button_forward = Button(root, text='>>', state=DISABLED)

    label.grid(row=0, column=0, columnspan=3)
    button_forward.grid(row=1, column=2)
    button_back.grid(row=1, column=0)

    current_image = image_number

    status = Label(root, text=f"Image {current_image} of {num_image}", bd=1, relief=SUNKEN, anchor=E, padx=6)
    status.grid(row=2, column=0, columnspan=3, sticky=W + E)


def back(image_number):
    global label
    global button_forward
    global button_back

    label.grid_forget()
    label = Label(image=image_list[image_number-1])
    button_forward = Button(root, text='>>', command=lambda: forward(image_number+1))
    button_back = Button(root, text='<<', command=lambda: back(image_number-1))

    if image_number == 1:
        button_back = Button(root, text='<<', state=DISABLED)

    label.grid(row=0, column=0, columnspan=3)
    button_forward.grid(row=1, column=2)
    button_back.grid(row=1, column=0)

    current_image = image_number

    status = Label(root, text=f"Image {current_image} of {num_image}", bd=1, relief=SUNKEN, anchor=E, padx=6)
    status.grid(row=2, column=0, columnspan=3, sticky=W + E)


button_back = Button(root, text='<<', command=back, state=DISABLED).grid(row=1, column=0)
button_exit = Button(root, text="EXIT PROGRAM", command=root.quit).grid(row=1, column=1)
button_forward = Button(root, text='>>', command=lambda: forward(2)).grid(row=1, column=2, pady=10)


root.mainloop()
 
 
 
 
 
 from tkinter import *
import tkinter as tk
# import tkMessageBox

# main window
root = Tk()
root.title('Calculator')

# button set
buttons = ['1','2','3','4','5','6','7','8','9','0','+','-','/','*','.']

sum_value = StringVar()

def appear(x):
    return lambda: output_window.insert(END,x)

# output window
output_window = tk.Entry(root, textvariable=sum_value, width=20, font = 'courier 10')
output_window.grid(row=0, columnspan=3, sticky=(E,W))

def equals():
    try:
        result = eval(output_window.get())
    except:
        result = 'INVALID'

    output_window.delete(0,END)
    output_window.insert(0,result)

def refresh():
    output_window.delete(0,END)

# button creation
r=1
c=0

for i in buttons:
    if c < 2:
        tk.Button(root, text = i, command = appear(i), pady = 3).grid(row = r, column = c, sticky = (N,S,E,W))
        c += 1
    else:
        tk.Button(root, text = i, command = appear(i), pady = 3).grid(row = r,column = c,sticky = (N,S,E,W))
        r  += 1
        c = 0

# clear and equal button
equal = tk.Button(root,text='=',padx = 5, pady=3, command=equals)
equal.grid(row=6,column=0,sticky=(N,S,E,W))

clear = tk.Button(root,text='CLEAR',padx = 5, pady=3,command = refresh)
clear.grid(row=6,column=1, columnspan = 2,sticky=(N,S,E,W))


#menu
menubar = Menu(root)

def quit1():
    if tkMessageBox.askokcancel("Quit","Are you sure you want to quit?"):
        root.destroy()

viewMenu = Menu(menubar)
viewMenu.add_command(label='Quit', command = quit1)
menubar.add_cascade(label="Home", menu=viewMenu)


root.config(menu=menubar)
root.mainloop()

 
 
 #Radiobutton

from tkinter import *
from PIL import Image, ImageTk

root = Tk()

MODES = [
    ("Gift", "Queendy"),
    ("Ifeanyi", "Johnbosco"),
    ("Mosh", "Mohamedana"),
    ("Samuel", "Ndubuisi"),
]

pizza = StringVar()
pizza.set("Queendy")

for text, mode in MODES:
    Radiobutton(root, text=text, variable=pizza, value=mode).pack(anchor=W)


def done(value):
    label = Label(root, text=value).pack()


button = Button(root, text="Click Me", command=lambda: done(pizza.get())).pack()





root.mainloop()




#MessageBox

from tkinter import *
from PIL import ImageTk, Image
from tkinter import messagebox

root = Tk()
root.title("Image View")
root.iconbitmap('D:\python\practice\image\icon.ico')

# messagebox.showinfo(), messagebox.showerror(), messagebox.showwarning(), messagebox.askokcancel()
# messagebox.askquestion(), messagebox.askretrycancel(), messagebox.askyesno(), messagebox.askyesnocancel()


def popup():
    response = messagebox.askquestion("About us", "This is all about us")
    label = Label(root, text=response).pack()

    # if response == 1:
    #     label = Label(root, text="I want to be a programmer").pack()
    # elif response == 0:
    #     label = Label(root, text="I always wanted to be a programmer").pack()
    # else:
    #     label = Label(root, command=root.quit)


button = Button(root, text="popup", command=popup).pack()


root.mainloop()




#TOPLEVEL SAMPLE

from tkinter import *
from PIL import ImageTk, Image
from tkinter import messagebox

root = Tk()
root.title("Examples")
root.iconbitmap('D:\python\practice\image\icon.ico')

clear1 = ImageTk.PhotoImage(Image.open('D:\python\practice\image\del.png'), size=23, width=50)
square_root = ImageTk.PhotoImage(Image.open('D:\python\practice\image\sqr.png'))
square = ImageTk.PhotoImage(Image.open('D:\python\practice\image\square.png'))
division = ImageTk.PhotoImage(Image.open('D:\python\practice\image\divi.png'))
percent2 = ImageTk.PhotoImage(Image.open('D:\python\practice\image\percentw.png'))


def tops():
    top = Toplevel()
    top.title("Examples")
    top.iconbitmap('D:\python\practice\image\icon.ico')



    entry = Entry(top, justify='right', width=32, relief=SUNKEN, insertwidth=12, font=("Tahoma", 15, "bold"))

    def buttons(number):
        current = entry.get()
        entry.delete(0, END)
        entry.insert(0, f"{current}{number}")

    def clear():
        entry.delete(first=0, last=END)

    # def point(number):
    #     entry.get()
    #
    #     entry.insert(1, number)
    #     entry.destroy

    def percent():
        try:
            first_number = entry.get()
            entry.delete(first=0, last=END)

            global first_num
            global operation
            operation = 'square'
            first_num = int(first_number)

            result = entry.insert(0, first_num / 100)
            return result
        except:
            entry.insert(0, "Invalid")

    def square_root1():
        first_number = entry.get()
        entry.delete(first=0, last=END)

        global first_num
        global operation
        operation = 'square'
        first_num = int(first_number)

        result = entry.insert(0, first_num ** 0.5)
        return result
        # output = math.sqrt(first_num)
        # return output

    def square1():
        first_number = entry.get()
        entry.delete(first=0, last=END)

        global first_num
        global operation
        operation = 'square'
        first_num = int(first_number)

        result = entry.insert(0, first_num * first_num)
        return result

    def plus():
        first_number = entry.get()
        global first_num
        global operation
        operation = 'plus'
        first_num = int(first_number)
        entry.delete(first=0, last=END)

    def minus():
        first_number = entry.get()
        global first_num
        global operation
        operation = 'minus'
        first_num = int(first_number)
        entry.delete(first=0, last=END)

    def times():
        first_number = entry.get()
        global first_num
        global operation
        operation = 'times'
        first_num = int(first_number)
        entry.delete(first=0, last=END)

    def divide():
        first_number = entry.get()
        global first_num
        global operation
        operation = 'divide'
        first_num = int(first_number)
        entry.delete(first=0, last=END)

    def equal():
        second_number = int(entry.get())
        entry.delete(first=0, last=END)

        global Operation

        if operation == 'plus':
            result = entry.insert(0, first_num + second_number)
            return result
        elif operation == 'minus':
            result = entry.insert(0, first_num - second_number)
            return result
        elif operation == 'times':
            result = entry.insert(0, first_num * second_number)
            return result
        elif operation == 'divide':
            result = entry.insert(0, first_num / second_number)
            return result

    button1 = Button(top, image=clear1, padx=10, pady=10, width=70, height=30, command=clear)
    button2 = Button(top, image=percent2, padx=10, pady=10, width=70, height=30, command=percent)
    button3 = Button(top, image=square_root, padx=40, pady=10, width=70, height=30, command=square_root1)
    button4 = Button(top, image=square, padx=40, pady=10, width=70, height=30, command=square1)

    button5 = Button(top, text='7', padx=30, pady=6, font=('arial', 10, "bold"), command=lambda: buttons(7))
    button6 = Button(top, text='8', padx=30, pady=6, font=('arial', 10, "bold"), command=lambda: buttons(8))
    button7 = Button(top, text='9', padx=30, pady=6, font=('arial', 10, "bold"), command=lambda: buttons(9))
    button8 = Button(top, image=division, padx=40, pady=10, width=70, height=30, command=divide)

    button9 = Button(top, text='4', padx=30, pady=6, font=('arial', 10, "bold"), command=lambda: buttons(4))
    button10 = Button(top, text='5', padx=30, pady=6, font=('arial', 10, "bold"), command=lambda: buttons(5))
    button11 = Button(top, text='6', padx=30, pady=6, font=('arial', 10, "bold"), command=lambda: buttons(6))
    button12 = Button(top, text='X', padx=30, pady=6, command=times)

    button13 = Button(top, text='1', padx=30, pady=6, font=('arial', 10, "bold"), command=lambda: buttons(1))
    button14 = Button(top, text='2', padx=30, pady=6, font=('arial', 10, "bold"), command=lambda: buttons(2))
    button15 = Button(top, text='3', padx=30, pady=6, font=('arial', 10, "bold"), command=lambda: buttons(3))
    button16 = Button(top, text='-', padx=30, pady=6, font=('arial', 10, "bold"), command=minus)

    button17 = Button(top, text='0', padx=30, pady=6, font=('arial', 10, "bold"), command=lambda: buttons(0))
    button18 = Button(top, text='.', padx=30, pady=6, font=('arial', 10, "bold"), command=lambda: buttons('.'))
    button_equal = Button(top, text='ANS', padx=30, pady=6, font=('arial', 10, "bold"), command=equal)
    button_plus = Button(top, text='+', padx=30, pady=6, font=('arial', 10, "bold"), command=plus)
    # button_exit = Button(top, text='Exit Program', padx=30, pady=6, anchor=E, font=('tahoma', 10, "bold"),
    #                      command=top.quit)

    entry.grid(row=0, column=0, columnspan=4, pady=10, padx=6)
    button1.grid(row=1, column=0, padx=10, pady=10)
    button2.grid(row=1, column=1, padx=10, pady=10)
    button3.grid(row=1, column=2, padx=10, pady=10)
    button4.grid(row=1, column=3, padx=10, pady=10)

    button5.grid(row=2, column=0, padx=10, pady=10)
    button6.grid(row=2, column=1, padx=10, pady=10)
    button7.grid(row=2, column=2, padx=10, pady=10)
    button8.grid(row=2, column=3, padx=10, pady=10)

    button9.grid(row=3, column=0, padx=10, pady=10)
    button10.grid(row=3, column=1, padx=10, pady=10)
    button11.grid(row=3, column=2, padx=10, pady=10)
    button12.grid(row=3, column=3, padx=10, pady=10)

    button13.grid(row=4, column=0, padx=10, pady=10)
    button14.grid(row=4, column=1, padx=10, pady=10)
    button15.grid(row=4, column=2, padx=10, pady=10)
    button16.grid(row=4, column=3, padx=10, pady=10)

    button17.grid(row=5, column=0, padx=10, pady=10)
    button18.grid(row=5, column=1, padx=10, pady=10)
    button_equal.grid(row=5, column=2, padx=10, pady=10)
    button_plus.grid(row=5, column=3, padx=10, pady=10)
    # button_exit.grid(row=6, column=0, columnspan=4, sticky=E, padx=10, pady=10)


button = Button(root, text="Calculator", command=tops).pack()


root.mainloop()




#Open Files

from tkinter import *
from PIL import ImageTk, Image
from tkinter import messagebox
from tkinter import filedialog

root = Tk()
root.title("Examples")
root.iconbitmap('D:\python\practice\image\icon.ico')

root.filename = filedialog.askopenfilename(initialdir="/", 
                                            filetypes=(("png files", "*.png"), ("All Files", "*.*")), 
                                            title="My Files")

img = ImageTk.PhotoImage(Image.open(root.filename))

label = Label(root, image=img).pack()

root.mainloop()



from tkinter import *
from PIL import ImageTk, Image
from tkinter import messagebox
from tkinter import filedialog

root = Tk()
root.title("Examples")
root.iconbitmap('D:\python\practice\image\icon.ico')
root.geometry('400x400')


def open(f):
    global horizontal
    root.geometry(str(horizontal.get())+"x"+str(vertical.get()))


horizontal = Scale(root, from_=[0], to=1000, orient=HORIZONTAL, command=open)
horizontal.pack()

vertical = Scale(root, from_=[0], to=500, command=open)
vertical.pack()


button = Button(root, text="Click me", command=open)
button.pack()

root.mainloop()





from tkinter import *
from PIL import ImageTk, Image
from tkinter import messagebox
from tkinter import filedialog

root = Tk()
root.title("Examples")
root.iconbitmap('D:\python\practice\image\icon.ico')
root.geometry('400x400')

var = StringVar()


def show():
    Label(root, text=var.get()).pack()


check = Checkbutton(root, text="Check Box", variable=var, onvalue="Paulinus", offvalue="None")
check.deselect()
check.pack()

button = Button(root, text="Check me", command=show).pack()

root.mainloop()
 


#DROPDOWN
from tkinter import *
from PIL import ImageTk, Image
from tkinter import messagebox
from tkinter import filedialog

root = Tk()
root.title("Examples")
root.iconbitmap('D:\python\practice\image\icon.ico')
root.geometry('400x400')


def show():
    global output, clicked

    output = str(clicked.get())

    response = messagebox.askokcancel(title="Days", message=output)


options = [
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday"
]


clicked = StringVar()
clicked.set(options[0])

drop = OptionMenu(root, clicked, *options)
drop.pack()

button = Button(root, text="Click", command=show).pack()

button = Button(root, text="close", command=root.quit).pack()

root.mainloop()







c.execute("INSERT INTO addresses VALUE(:first_name, :last_name, :address, :city, :state)",




sqlites
import sqlite3 as sql

con = sql.connect("employee.db")

cursor = con.cursor()

cursor.execute("""CREATE TABLE IF NOT EXISTS employees(
                    first text,
                    last text,
                    pay integer
                )""")

cursor.execute("INSERT INTO employees VALUES('PAULINUS', 'OSdHI', 43000)")
cursor.execute('commit')
cursor.execute("DELETE FROM employees WHERE first='PAULINUS'")
cursor.execute("SELECT * FROM employees")
rows = cursor.fetchall()

print(rows)

# for row in rows:
#     print(f"I, {row[1]} {row[0]} Donates the sum of ${row[2]}")
#     # print(f"Last Name:  {row[1]}")


con.commit()
con.close()






#DATABASE CONNECTION
import _sqlite3 as mysql
from tkinter import *
from tkinter import messagebox as message

root = Tk()
root.geometry("1000x600")



# cursor.execute("""CREATE TABLE class(
#                 first_name text,
#                 last_name text,
#                 address text,
#                 gender text,
#                 phone_number integer
#                 )""")

genderm = StringVar()


def std_list():
    con = mysql.connect('eminent.db')
    cursor = con.cursor()

    cursor.execute("SELECT * FROM class")

    rows = cursor.fetchall()
    list.delete(0, list.size())

    for row in rows:
        insertData = f"{row[1]}    {row[0]}    {row[2]}    {row[3]}    {row[4]}"
        list.insert(list.size()+1, insertData)

    # cursor.execute('commit')


def submit():
    f_name = e_first_name.get().upper()
    l_name = e_last_name.get().upper()
    genders = genderm.get().upper()
    location = e_address.get().upper()
    phone_num = e_phone.get()

    if (f_name=="" or l_name=="" or location=="" or phone_num==""):
        message.showinfo("Message", "All Fields are required")
    else:
        con = mysql.connect('eminent.db')
        cursor = con.cursor()
        cursor.execute("SELECT * FROM class")
        rows = cursor.fetchall()

        for row in rows:
            if(row[0]==f_name):
                message.showinfo("Message", "The Name has been used")
                break
        else:
            if(cursor.execute("INSERT INTO class VALUES('"+ f_name +"', '"+ l_name +"', '"+ location +"', '"+ genders +"', '"+ phone_num +"')")):
                cursor.execute('commit')
                message.showinfo("Message", "Submitted Successfuly")

        e_first_name.delete(0, END)
        e_last_name.delete(0, END)
        e_address.delete(0, END)
        e_phone.delete(0, END)
        std_list()
        # genderm.delete(0, END)

        cursor.execute('commit')
        # con.close()


def get():
    f_name = e_first_name.get().upper()
    # l_name = e_last_name.get()
    # genders = genderm.get()
    # location = e_address.get()
    # phone_num = e_phone.get()

    if (f_name == ""):
        message.showinfo("Message", "The First Name is needed")
    else:
        # top = Toplevel()
        con = mysql.connect('eminent.db')
        cursor = con.cursor()
        cursor.execute("SELECT * FROM class WHERE first_name='"+ f_name +"'")

        rows = cursor.fetchall()

        for row in rows:
            if(row[0]==f_name):
                top = Toplevel()
                top.geometry("1000x600")
                label = Label(top, text=rows).pack()

            else:
                message.showinfo("Message", "Not found in the List of Students")
            break


            # message.showinfo("Message", "Submitted Successfuly")

            # e_first_name.delete(0, END)
            # e_last_name.delete(0, END)
            # e_address.delete(0, END)
            # e_phone.delete(0, END)
            # # genderm.delete(0, END)

        # cursor.execute('commit')
        # con.close()


def delete():
    con = mysql.connect('eminent.db')
    cursor = con.cursor()
    f_name = e_first_name.get().upper()

    if (f_name == ""):
        message.showinfo("Message", "The First Name is needed")
    else:
        clear = cursor.execute("DELETE FROM class WHERE first_name='" + f_name + "'")
        cursor.execute('commit')

        if clear:
            message.showinfo("Message", "Deleted Successfully")
        else:
            message.showinfo("Message", "Didn't Found such Name")


    std_list()

    con.close()

# def std_list():
#     con = mysql.connect('eminent.db')
#     cursor = con.cursor()
#
#     cursor.execute("SELECT * FROM class")
#     rows = cursor.fetchall()
#     list.delete(0, list.size())
#
#     for row in rows:
#         insertData = f"{row[1]}    {row[0]}    {row[2]}    {row[3]}    {row[4]}"
#         list.insert(list.size()+1, insertData)





first_name = Label(root, text="First Name:", pady=14, font=("Tahoma", 15, "bold"))
first_name.place(x=20, y=30)
e_first_name = Entry(root, width=30, font=("Tahoma", 10, "bold"))
e_first_name.place(x=140, y=50)

last_name = Label(root, text="Last Name:", pady=14, font=("Tahoma", 15, "bold"))
last_name.place(x=380, y=30)
e_last_name = Entry(root, width=30, font=("Tahoma", 10, "bold"))
e_last_name.place(x=500, y=50)

address = Label(root, text="Address:", pady=14, font=("Tahoma", 15, "bold"))
address.place(x=20, y=90)
e_address = Entry(root, width=30, font=("Tahoma", 10, "bold"))
e_address.place(x=140, y=110)

gender = Label(root, text="Gender:", pady=14, font=("Tahoma", 15, "bold"))
gender.place(x=380, y=90)

radio_male = Radiobutton(root, text="Male", variable=genderm, value="Male", font=("Tahoma", 15, "bold"))
radio_male.place(x=480, y=100)
radio_female = Radiobutton(root, text="Female", variable=genderm, value="Female", font=("Tahoma", 15, "bold"))
radio_female.place(x=570, y=100)

phone = Label(root, text="Phone No:", pady=14, font=("Tahoma", 15, "bold"))
phone.place(x=20, y=150)
e_phone = Entry(root, width=30, font=("Tahoma", 10, "bold"))
e_phone.place(x=140, y=170)

submit_btn = Button(root, text="Submit", font=("tahoma", 15, "bold"),
                    bg="green", fg="white", command=submit).place(x=400, y=160)

get_btn = Button(root, text="Get", font=("tahoma", 15, "bold"),
                    bg="black", fg="white", command=get).place(x=490, y=160)

delete_btn = Button(root, text="Delete", font=("tahoma", 15, "bold"),
                    bg="red", fg="white", command=delete).place(x=550, y=160)

exit_btn = Button(root, text="Close", font=("tahoma", 15, "bold"),
                    bg="yellow", fg="black", command=root.quit).place(x=650, y=160)


list = Listbox(root, width=90, height=20)
list.place(x=20, y=220)
std_list()


root.mainloop()





import pygame
from pygame import mixer
import math
import random
from tkinter import *
from tkinter import messagebox as message

pygame.init()

screen = pygame.display.set_mode((800, 600))

background = pygame.image.load('background.png')

pygame.display.set_caption("SPACE INVADERS")
icon = pygame.image.load('transport.png')
pygame.display.set_icon(icon)

playerImg = pygame.image.load('gaming.png')
playerX = 370
playerY = 500
playerX_change = 0


def player(x, y):
    screen.blit(playerImg, (x, y))



enemyImg = []
enemyX = []
enemyY = []
enemyY_change = []
enemyX_change = []
num_of_enemies = 6

for i in range(num_of_enemies):
    global score_value
    enemyImg.append(pygame.image.load('enemy.png'))
    enemyX.append(random.randint(0, 735))
    enemyY.append(random.randint(30, 150))
    enemyY_change.append(20)
    enemyX_change.append(4)


def enemy(x, y, i):
    screen.blit(enemyImg[i], (x, y))


bulletImg = pygame.image.load('bullet.png')
bulletX = 0
bulletY = 480
bullet_state = "ready"
bulletY_change = 15
bulletX_change = 0


def bullet_shoot(x, y):
    global bullet_state
    bullet_state = "fired"
    screen.blit(bulletImg, (x + 16, y + 10))


def iscollision(bulletX, bulletY, enemyX, enemyY):
    distance = math.sqrt(math.pow(bulletX - enemyX, 2) + math.pow(bulletY - enemyY, 2))
    if distance < 34:
        return True
    else:
        return False


score_value = 0
font = pygame.font.Font('freesansbold.ttf', 32)
textX = 10
textY = 10


def show_score(x, y):
    score = font.render("Score : " + str(score_value), True, (255, 255, 255))
    screen.blit(score, (x, y))


end_game = pygame.font.Font('freesansbold.ttf', 72)


def game_over_text():
    over_text = end_game.render("GAME OVER", True, (255, 0, 255))
    screen.blit(over_text, (200, 250))


running = True
while running:

    screen.fill((0, 0, 0))
    screen.blit(background, (0, 0))

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
            # response = message.askyesno("Exit Game", "Are you sure You want to exit")
            # if response is True:
            #
            # else:
            #     pass

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                playerX_change -= 4

            if event.key == pygame.K_RIGHT:
                playerX_change += 4

            if event.key == pygame.K_SPACE:
                if bullet_state is "ready":
                    bulletX = playerX
                    # bullet_state is "fired"
                    bullet_shoot(bulletX, bulletY)

        if event.type == pygame.KEYUP:
            playerX_change = 0

    playerX += playerX_change

    # Player Boundary
    if playerX <= 0:
        playerX = 0

    if playerX >= 736:
        playerX = 736

    if bulletY <= 0:
        bulletY = 480
        bullet_state = "ready"

    if bullet_state is "fired":
        bullet_shoot(bulletX, bulletY)
        bulletY -= bulletY_change

    # bullet_shoot(playerX, bulletY)
    player(playerX, playerY)

    # Enemy Movement
    for i in range(num_of_enemies):

        # GAME OVER

        if enemyY[i] >= 440:
            for j in range(num_of_enemies):
                enemyY[j] = 2000
            game_over_text()
            break

        enemyX[i] += enemyX_change[i]
        if enemyX[i] >= 736:
            enemyX_change[i] -= 4
            enemyY[i] += enemyY_change[i]
        if enemyX[i] <= 0:
            enemyX_change[i] += 4
            enemyY[i] += enemyY_change[i]

        collision = iscollision(bulletX, bulletY, enemyX[i], enemyY[i])
        if collision:
            bulletY = 480
            bullet_state = "ready"
            score_value += 5
            enemyX[i] = random.randint(0, 735)
            enemyY[i] = random.randint(30, 150)

        enemy(enemyX[i], enemyY[i], i)

    show_score(textX, textY)
    pygame.display.update()




import pygame
from pygame.locals import *

pygame.init()

size = 640, 320
width, height = size
RED = (255, 0, 0)
GREEN = (0, 255, 0)

screen = pygame.display.set_mode((size))

ball = pygame.image.load('bullet.png')

rect = ball.get_rect()
rect.left
rect.top
rect.bottom
rect.right

speed = [2, 2]


running = True
while running:
    for event in pygame.event.get():

        screen.fill(GREEN)

        if event.type == pygame.QUIT:
            running = False

    rect = rect.move(speed)

    if rect.left < 0 or rect.right > width:
        speed[0] = -speed[0]

    if rect.top < 0 or rect.bottom > height:
        speed[1] = -speed[1]

    pygame.draw.rect(screen, RED, rect, 1)

    screen.blit(ball, rect)

    pygame.display.update()






import pygame

pygame.init()

screen = pygame.display.set_mode((400, 350))

rect_color = (253, 62, 245)

start = (0, 0)
size = (0, 0)
drawing = False

rect_list = []

running = True
while running:
    
    screen.fill((255, 255, 255))
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        if event.type == pygame.MOUSEBUTTONDOWN:
            start = event.pos
            size = 0, 0
            drawing = True

        elif event.type == pygame.MOUSEBUTTONUP:
            end = event.pos
            size = end[0] - start[0], end[1] - start[1]
            drawing = False
            

        elif event.type == pygame.MOUSEMOTION and drawing:
            end = event.pos
            size = end[0] - start[0], end[1] - start[1]


    recta = pygame.draw.rect(screen, rect_color, (start, size), 2)
    rect_list.append(recta)

    pygame.display.update()
pygame.quit()



































































































































































































































































































































































































































	
	