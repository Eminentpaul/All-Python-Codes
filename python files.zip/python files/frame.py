from tkinter import *
from PIL import ImageTk, Image

root = Tk()

frame = LabelFrame(root, text="This is my Frame", bd=3, bg="blue", fg="orange")
frame.pack()

button = Button(frame, text="Exit", command=root.quit)
button.pack()

root.mainloop()
