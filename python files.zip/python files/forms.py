from tkinter import *
from PIL import ImageTk, Image
from tkinter import messagebox
from tkinter import filedialog
import sqlite3

root = Tk()
root.title("Examples")
root.iconbitmap('D:\python\practice\image\icon.ico')
root.geometry('400x400')

# Create or connect to a database?
conn = sqlite3.connect("address_book.db")

# Create a cursor
c = conn.cursor()


def record():
    # Create or connect to a database?
    conn = sqlite3.connect("address_book.db")

    # Create a cursor
    c = conn.cursor()

    # Insert into the table
    c.execute("INSERT INTO addresses VALUE(:first_name, :last_name, :address, :city, :state)",
              {
                  'first_name': first_name.get(),
                  'last_name': last_name.get(),
                  'address': address.get(),
                  'city': city_input.get(),
                  'state': state_input.get(),
                  # 'zipcode': zip_code.get()
              }
              )

    # commit database
    conn.commit()

    # Close Connection
    conn.close()

    first_name.delete(0, END)
    last_name.delete(0, END)
    address.delete(0, END)
    city_input.delete(0, END)
    state_input.delete(0, END)
    # zip_code.delete(0, END)


# Create Table
# c.execute("""CREATE TABLE addresses(
#     first_name text,
#     last_name text,
#     address text,
#     city text,
#     state text,
#     zipcode integer
# )
#
# """)
f_name = Label(root, text="First Name", width=20)
f_name.grid(row=0, column=0, pady=10)
first_name = Entry(root, width=30)
first_name.grid(row=0, column=1, padx=20)

l_name = Label(root, text="Last Name", width=10)
l_name.grid(row=1, column=0)
last_name = Entry(root, width=30)
last_name.grid(row=1, column=1, padx=20)

addres = Label(root, text="Address", width=20)
addres.grid(row=2, column=0, pady=10)
address = Entry(root, width=30)
address.grid(row=2, column=1, padx=20)

city_name = Label(root, text="City", width=20)
city_name.grid(row=3, column=0, pady=10)
city_input = Entry(root, width=30)
city_input.grid(row=3, column=1, padx=20)

state_name = Label(root, text="State", width=20)
state_name.grid(row=4, column=0, pady=10)
state_input = Entry(root, width=30)
state_input.grid(row=4, column=1, padx=20)

# zip = Label(root, text="ZipCode", width=20)
# zip.grid(row=5, column=0, pady=10)
# zip_code = Entry(root, width=30)
# zip_code.grid(row=5, column=1, padx=20)

button = Button(root, text="Submit", command=record)
button.grid(row=6, column=0, columnspan=2, padx=15, ipadx=100)

# commit database
conn.commit()

# Close Connection
conn.close()
root.mainloop()
