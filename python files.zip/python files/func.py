# Optional Parameters Tutorial #1

#class car(object):
 #   def __init__(self, make, model, year, condition, kms):
  #      self.make = make
   ##    self.year = year
     #   self.condition = condition
        #self.kms = kms
        
    #def display(self, showAll):
        #if showAll:
     #       print("This Car %s %s from %s, it is %s and has %s kms." %(self.make, self.model, self.year, self.condition, self.kms))
        #else:
         #   print("This is a %s %s from %s" %(self.make, self.model, self.year))
            
#whip = c#ar('ford', 'Fusion', 2012, 'New', 0)

#whip.dis#play(True)

"""
ages = int(input('> '))
names = input("> ")
class person(object):
    population = 50
    
    def __init__(self, name, age):
        self.name = name
        self.age = age
    
    @classmethod
    def getPopulation(cls):
        return cls.population
    
    @staticmethod
    def isAdult(age):
        return age >= 18
    
    def display(self):
        print(self.name, 'is', self.age, 'years old')
        
        
newperson = person(names, ages)

if person.isAdult(ages):
    newperson.display()
else:
    print('Not Eligible')"""



#mapping tutorial
"""
li = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

def func(x):
    return x ** x

print(list(map(func, li)))
print([func(x) for x in li if x%2==0])
"""


#Filter tutorial
"""
def add(x):
    return x + 7
    
def isOdd(x):
    return x%2 != 0
    
a = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

b = list(filter(isOdd, a))

print(b)

c = list(map(add, b))
print(c)


b = list(filter(add, a))
print(b)"""


#lambda
'''
value = lambda x, y: x+3 * y
print(value(3, 4))'''


#Collection and Counter

import collections
from collections import Counter


#containers
#list
#set
#dict
#tuple - immutable


#Types
#1 count <- This video
#2 deque
#3 namedTuple()
#4 orderdDict
#5 defaultDict






































