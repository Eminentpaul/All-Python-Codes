secret_number = 17
guess_count = 0
guess_limit = 3

while guess_count < guess_limit:
    guess = int(input("Guess the correct number: "))
    guess_count += 1
    if guess != secret_number:
        print('Not correct')
    elif guess == secret_number:
        print('That is correct!')
        print('You Won!')
        break
else:
    print("Sorry you failed!")