from tkinter import *
from PIL import ImageTk, Image

root = Tk()
root.title('Image Viewer')
root.iconbitmap('D:\python\image_viewer\image\icon.ico')

img1 = ImageTk.PhotoImage(Image.open('D:\python\image_viewer\image\me1.jpg'))
img2 = ImageTk.PhotoImage(Image.open('D:\python\image_viewer\image\me2.jpg'))
img3 = ImageTk.PhotoImage(Image.open('D:\python\image_viewer\image\me3.jpg'))
img4 = ImageTk.PhotoImage(Image.open('D:\python\image_viewer\image\me4.jpg'))
img5 = ImageTk.PhotoImage(Image.open('D:\python\image_viewer\image\me5.jpg'))


image_list = [img1, img2, img3, img4, img5]

view = Label(image=img1)
view.grid(row=0, column=0, columnspan=3)

total_image = len(image_list)
status = Label(root, text=f"Image 1 of {total_image}", relief=SUNKEN, bd=1, anchor=E)
status.grid(row=2, column=0, columnspan=3, sticky=W+E)


def button_forward(image_number):
    global view
    global back_button
    global forward_button

    view.grid_forget()
    view = Label(image=image_list[image_number-1])
    forward_button = Button(root, text=">>", command=lambda: button_forward(image_number + 1))
    back_button = Button(root, text="<<", command=lambda: button_back(image_number-1))

    if image_number == 5:
        forward_button = Button(root, text=">>", state=DISABLED)

    current = image_number

    status = Label(root, text=f"Image {current} of {total_image}", relief=SUNKEN, bd=1, anchor=E)
    status.grid(row=2, column=0, columnspan=3, sticky=W + E)

    view.grid(row=0, column=0, columnspan=3)
    back_button.grid(row=1, column=0)
    forward_button.grid(row=1, column=2)


def button_back(image_number):
    global view
    global back_button
    global forward_button

    view.grid_forget()
    view = Label(image=image_list[image_number - 1])
    forward_button = Button(root, text=">>", command=lambda: button_forward(image_number + 1))
    back_button = Button(root, text="<<", command=lambda: button_back(image_number-1))

    if image_number == 1:
        back_button = Button(root, text="<<", state=DISABLED)

    current = image_number

    status = Label(root, text=f"Image {current} of {total_image}", relief=SUNKEN, bd=1, anchor=E)
    status.grid(row=2, column=0, columnspan=3, sticky=W + E)

    view.grid(row=0, column=0, columnspan=3)
    back_button.grid(row=1, column=0)
    forward_button.grid(row=1, column=2)


back_button = Button(root, text="<<", command=button_back, state=DISABLED)
exit_button = Button(root, text="Exit Program", command=root.quit)
forward_button = Button(root, text=">>", command=lambda: button_forward(2))

back_button.grid(row=1, column=0)
exit_button.grid(row=1, column=1, pady=10)
forward_button.grid(row=1, column=2)



root.mainloop()
