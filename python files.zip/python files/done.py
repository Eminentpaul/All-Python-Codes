
command = ""
while True:
    command = input("> ").lower()
    if command == "help":
        print("""
Start - to start the car
Stop - to stop the car
quit - to exit
        """)
    
    elif command == "start":
        print("Car started... Ready to go!")

    elif command == "stop":
        print("Car has Stopped!")

    elif command == "quit":
        break
    else:
        print("I don't understand this !!!")



