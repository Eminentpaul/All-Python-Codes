# Optional Parameters Tutorial #1

class car(object):
    def __init__(self, make, model, year, condition, kms):
        self.make = make
        self.model = model
        self.year = year
        self.condition = condition
        self.kms = kms

    def display(self, showAll):
        if showAll:
            print("This Car if a %s %s from %s, it is %s and has %s kms." %(self.make, self.model, self.year, self.condition, self.kms))
        else:
            print("This is a %s %s from %s" %(self.make, self.model, self.year))


whip = car('ford', 'Fusion', 2012, 'New', 0)

whip.display(False)