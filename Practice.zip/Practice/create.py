from tkinter import *
from tkinter import ttk, messagebox as mg
from ttkthemes import themed_tk as tk
import sqlite3
import _datetime as d
import os
import tempfile


dated = d.datetime.today()
table_name = dated.date()

year = table_name.year
month = table_name.month
day = table_name.day

index = 1
global Daily
Daily = f"{str(day)}_{str(month)}_{str(year)}"

con = sqlite3.connect("Mary_Daniella.db")
cursor = con.cursor()

table = f"""CREATE TABLE IF NOT EXISTS Customers_{year}(
    Customers text,
    Kg text
)"""

if(cursor.execute(table)):
    print(table)
else:
    print("Not Successful")
# # cursor.execute("commit")
#
# con = sqlite3.connect(f'Year_{year}.db')
# cursor = con.cursor()
#
# expense_month = f"""CREATE TABLE IF NOT EXISTS Expense_{month}(
#                 Description text,
#                 Amount integer)"""
# income_month = f"""DROP TABLE Sales_{month}"""
# sales = f"""CREATE TABLE IF NOT EXISTS Trans_{year}(
#         Month text,
#         Total_Kg integer,
#         Total_Exp integer,
#         Total_Amount integer)"""
# cursor.execute(expense_month)
# cursor.execute(income_month)
# cursor.execute(sales)

con.close()