# from pprint import pprint as print

# # smallest = None
# # print("Before: ", smallest)
# #
# # x = [3, 41, 12, 9, 74, 15, 1]
# # for  i in x:
# #     smallest = x[0]
# #     if i < smallest:
# #         smallest = i
# # print("Smallest: ",smallest)
#
#
# x = "eminent2547@gmail.com"
# pos = x.find("@")
# print(x[:pos])
# print(x[pos+1:])
# print(pos)
#
# # print(x.find("l"))

# xfile = open('done.txt')
# # d = xfile.read()
# # print(len(d))
#
# for line in xfile:
#     line = line.rstrip()
#     if line.startswith("From:"):
#         print(line)

# friends = ['Ogochukuw', 'Rita', "Scholastica", 'Samuel']
# for friend in friends:
#     print("Happy New Year ", friend)

# x = list()
# print(type(x))
# print(dir(x))

# words = 'His e-mail is q-lar@freecodecamp.org'
# pieces = words.split()
# parts = pieces[3].split(".")
# print(parts)

# names = ['paul', 'susan', 'nessa', 'ogoo']
# ages = [25, 38, 33, 29]
# done = {}
#
# d = ''
# c = 0
# for x in names:
#     for z in ages:
#         pass
# done[f'{x}'] = z

# print(done)

# count = dict()
# names = ['csev', 'cwen', 'csev', 'zqian', 'cwen']
#
# for name in names:
#     count[name] = count.get(name, 0) + 1
#     # if name not  in count:
#     #     count[name] = 1
#     # else: count[name] += 1
# print(count)
# print(count.items())

import re
#
xfile = open('done.txt')
lines = xfile.read()
words = dict()
d = lines.split()
# for word in d:
#     words[word] = words.get(word, 0) + 1
#
# value = sorted([(val, key) for key, val in words.items()], reverse=True)
# print(value)

# highOccuranceWord = None
# occurance = 0
#
# for wod, count in words.items():
#     if count > occurance:
#         occurance = count
#         highOccuranceWord = wod
#
# print(f'{highOccuranceWord} occurs {occurance} times')

# for line in lines:
#     line = line.lstrip()
#     counts[line] = counts.get(line, 0) + 1
# word = None
# big = None
# for x, v in counts.items():
#     if big is None or v > big:
#         big = v
#         word = x
# print(word, big)


# if re.search("is", d):
