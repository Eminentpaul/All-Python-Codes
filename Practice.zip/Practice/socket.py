import socket
s = socket.s