# from _datetime import datetime as d
# 
# now = d.today()
# d = d.day
# print(d)
# print(now)
# 

import webbrowser

print('Deployment Completed')
webbrowser.open("https://google.com")
