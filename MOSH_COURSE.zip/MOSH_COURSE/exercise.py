# from pprint import pprint
# sentence = "This is an interview questions"
# char_frequence = {}
#
# for char in sentence:
#     if char in char_frequence:
#         char_frequence[char] += 1
#     else:
#         char_frequence[char] = 1
# print(char_frequence)
#
# done = sorted(char_frequence.items(), key=lambda k:k[1], reverse=True)
# # pprint(done)
#
# try:
#     age = int(input("Age: "))
# except ValueError:
#     print("You did not enter a valid number")


# class Point:
#     default_color = "Orange"
#
#     def __init__(self, x, y):
#         self.x = x
#         self.y = y
#
#     def __str__(self):
#         return f"({self.x}, {self.y})"
#
#     def draw(self):
#         print("Draw")
#
#     def __eq__(self, other):
#         return self.x == other.x and self.y == other.y
#
#     def __add__(self, other):
#         return Point(self.x + other.x, self.y + other.y)
#
# pin = Point(1, 3)
# other = Point(1, 3)
# print(pin + other)
# print(pin.draw())
# print(str(pin))


# class Add:
#     def __init__(self, x, y):
#         self.x = x
#         self.y = y
#
#     def __add__(self):
#         return self.x + self.y
#
#
# value = int(input("> "))
# vl = int(input("> "))
#
# add = Add(value, vl)
# print(add)

# class TagCloud:
#     def __init__(self):
#         self.__tags = {}
#
#     def add(self, tag):
#         self.__tags[tag.lower()] = self.__tags.get(tag.lower(), 0) + 1
#
# cloud = TagCloud()
# cloud.add("Python")
# cloud.add("Python")
# cloud.add("Python")
# cloud.add("Python")
# print(cloud.__tags)


# class Animal:
#     def walk(self):
#         print("Aninal walks")
#
#
# class Mammal(Animal):
#     def bark(self):
#         print("Dogs always barks")
#
#
# dog = Mammal()


from main import calc_tax, calc_loan
from ecommerce.done import calc_loan
# import sys

# print(sys.path)

# done = calc_tax()
print(calc_loan())





