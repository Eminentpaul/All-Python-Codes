# # # while True:
# # #     data = int(input("> "))
# # #
# # #     if data % 3 == 0 and data % 5 == 0:
# # #         print("FizzBuzz")
# # #     elif data % 3 == 0:
# # #         print("Fizz")
# # #     elif data % 5 == 0:
# # #         print("Buzz")
# # #     else:
# # #         print(data)
# #
# #
# # items = [
# #     ("Porduct1", 10),
# #     ("Pruduct2", 3),
# #     ("Product3", 55),
# #     ("Product4", 23)
# # ]
# #
# # def sorted_item(item):
# #     return item[1]
# #
# # items.sort(key=sorted_item, reverse=True)
# #
# # print(items)
#
#
# # items = [
# #     ("Porduct1", 10),
# #     ("Pruduct2", 3),
# #     ("Product3", 55),
# #     ("Product4", 23)
# # ]
# #
# # items.sort(key=lambda item:item[1])
# # print(items)
# #
# # x = list(map(lambda item:item[1], items))
# # print(x)
# #
# # y = list(filter(lambda item: item[1] >= 10, items))
# # print(y)
#
#
# # from collections import deque
# #
# # queue = deque([])
# #
# # queue.append(1)
# # queue.append(2)
# # queue.append(3)
# # queue.append(4)
# #
# # print(queue)
# # done = queue.popleft()
# # print(queue)
# #
# # if not queue:
# # #     print("empty")
# #
# # print("Enter help to show you what you can do")
# # help = """
# # start - To Start the Car
# # stop - To Stop the Car
# # quite - To Quite the program
# # """
# #
# # while True:
# #     done = input("> ").lower()
# #     if done == "help":
# #         print(help)
# #     elif done == "start":
# #         print("Car has Started!")
# #     elif done == "stop":
# #         print("Car Stopped!!!")
# #     elif done == "quite":
# #         break
# #     else:
# #         print("Invalid Input")
#
# # x = 11
# # y = 12
# # x, y = y, x
# #
# # print("x", x)
# # print("y", y)
#
#
# # numbers = (1, 2, 2, 3, 1, 4, 3)
# # unique = set(numbers)
# # print(unique)
# #
# # second = {3, 4, 6, 9}
# #
# # print(unique - second)
# # print(unique | second)
# # print(unique & second)
# # print(unique ^ second)
#
# # point = {
# #     "x": 2,
# #     "y": 3
# # }
# #
# # print(point)
# #
# # for x, y in point.items():
# #     print(x, y)
#
# # values = []
# #
# # for x in range(5):
# #     values.append(x * 2)
# # print(values)
# #
# # value = [x * 2 for x in range(5)]
# # print(value)
#
# from pprint import pprint
#
sentence = "This is a common interview question"

char_frequency = {}

for char in sentence:
    if char in char_frequency:
        char_frequency[char] += 1
    else:
        char_frequency[char] = 1
# pprint(char_frequency)

don = sorted(char_frequency.items(), key=lambda k:k[1], reverse=True)
print(don)


#


def calc_tax():
    print("You have to pay your tax")


def calc_loan():
    print("Your loan is always available")