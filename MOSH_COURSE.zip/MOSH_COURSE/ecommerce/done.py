def calc_tax():
    print("You have to pay your tax")


def calc_loan():
    print("Your loan is always available")