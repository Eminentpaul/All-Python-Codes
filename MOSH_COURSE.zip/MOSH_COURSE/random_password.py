import random
import string

r = random.random()
print(random.randint(1, 20))

print("".join(random.choices(string.ascii_letters + string.digits, k=8)))
print("paulinus".upper())