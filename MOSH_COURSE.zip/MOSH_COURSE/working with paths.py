from pathlib import Path
from time import ctime
from zipfile import ZipFile
import csv
import json

# path = Path("ecommerce/__init__.py")
# #Path.exists() # That returns a boolean
# #Path.mkdir() # To make a directory
#
#
#
# # for p in path.iterdir():
# #     print(p)
#
# path.exists()
# print(ctime(path.stat().st_ctime))

# zip = ZipFile("files.zip", "w")
# for path in Path("ecommerce").rglob("*.*"):
#     zip.write(path)
# zip.close()

# with ZipFile("file.zip", "w") as zip:
#     for path in Path("ecommerce").rglob("*.*"):
#         zip.write(path)

# with ZipFile("file.zip") as zip:
#     p = zip.namelist()
#     print(p)
#     d = zip.getinfo('ecommerce/done.py')
#     print(d.file_size, d.compress_type, d.compress_size)
#     zip.extractall("extracts") # To extract the files

# with open("data.csv", 'w') as file:
#     writer = csv.writer(file)
#     writer.writerow(["Transaction_id","Product_id","Price"])
#     writer.writerow([1000,1,10])
#     writer.writerow([1001,2,15])

# with open("data.csv") as file:
#     reader = csv.reader(file)
#     # print(list(reader))
#     for row in reader:
#         print(row)

# movies = [
#     {"id": 1, "Title": "Terminator", "year": 1989},
#     {"id": 2, "Title": "Kindergarten Cop", "year": 1993}
# ]
# 
# data = json.dumps(movies)
# Path("movies.json").write_text(data)

data = Path("movies.json").read_text()
movies = json.loads(data)

print(movies[0])







