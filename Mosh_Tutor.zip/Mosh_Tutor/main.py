import numpy as np

# array = np.array([ [1, 2, 3], [4, 5, 6] ])
# print(array)
# print(array.shape)
#
# z = np.zeros((3, 4), dtype=int)
# n = np.ones((3,4), dtype=int)
# q = np.full((3,4), 22)
# print(z)
# print(n)
# print(q)

x = np.random.random((2, 3))
print(x)
print(x > 0.3)